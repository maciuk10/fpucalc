/**
  ******************************************************************************
  * @file    main.c
  * @author  Maciej Grzela
  * @version V1.0
  * @date    12-May-2019
  * @brief   Assembly IEEE Serial Port Calculator.
  *
  *
  * Program wykonuj�cy obliczenia na operandach zmiennoprzecinkowych otrzymanych
  * z portu szeregowego.
  *
  * Program akceptuje nast�puj�ce komendy:
  *
  *  o;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx; - dl: 68
  *
  *  gdzie:
  *  o - kod operacji
  *  x - bity okre�lonego operandu
  *
  * Wyr�nione kody operacji:
  *	 + - dodawanie
  *  - - odejmowanie
  *  * - mno�enie
  *  / - dzielenie
  *  ! - druga potega
  *  s - pierwiastek
  *	 i - odwrotnosc
  *
  *
  *  ******************************************************************************
*/

#include "stm32f10x.h"
#include "string.h"
#include "math.h"
#include <stdio.h>
#include <stdlib.h>

void prepareBinary(char op[], unsigned int * operand);

int commandLength = -1;

char c_operand1[32];
char c_operand2[32];

unsigned int op1;
unsigned int op2;
unsigned int opResult;
char opcode;

char result[32];
char command[68];

void sendChar(char c) {
	while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
	USART_SendData(USART2, c);
}

void sendString(char* string){
	while(*string){
		sendChar(*string++);
	}
}

void sendArray(char array[], int length){
	int i;
	for(i = 0; i < length; i++){
		sendChar(array[i]);
	}
}

int __io_putchar(int c) {
    if (c=='\n')
        sendChar('\r');
    sendChar(c);
    return c;
}


void decodeOpcode(char opcode){
	switch(opcode){
		case '+':
		case '-':
		case '*':
		case '/':
		case '!':
		case 's':
		case 'i':
			commandLength = 68;
			break;
		default:
			commandLength = -2;
			break;
		}
}

void prepareOperands(){
	opcode = command[0];
	int i;
	for(i = 0; i < 32; i++){
		c_operand1[i] = command[i+2];
	}
	if(commandLength == 68){
		for(i = 0; i < 32; i++){
			c_operand2[i] = command[i+35];
		}
		prepareBinary(c_operand2, &op2);
	}
	prepareBinary(c_operand1, &op1);
	doComputation();
}

void prepareBinary(char op[], unsigned int * operand) {
    unsigned int n = 0;
    int i;
    for (i = 0; i < 32; ++i) {
        n <<= 1;
        n += op[i] - '0';
    }
    *operand = n;
}

void prepareResult(){
	int c;
	int j = 0;
	unsigned int k;
	for(c = 31; c >= 0; c--){
		k = opResult >> c;
		if(k & 1){
			result[j] = '1';
		}else {
			result[j] = '0';
		}
		j++;
	}
}

void doComputation(){
	switch(opcode){
		case '+':
			floatAdd();
			prepareResult();
			break;
		case '-':
			floatSub();
			prepareResult();
			break;
		case '*':
			floatMul();
			prepareResult();
			break;
		case '/':
			floatDiv();
			prepareResult();
			break;
		case '!':
			floatPow();
			prepareResult();
			break;
		case 's':
			floatSqrt();
			break;
		case 'i':
			floatInverse(0);
			prepareResult();
			break;
	}
}

void floatAdd(){
	unsigned int wynik = 0;
	unsigned int przeciwne = op1^op2;
	if(przeciwne == 0x80000000){
		wynik = 0;
	}else {
		asm(
					"mov r1, %1\t\n"
					"mov r2, %2\t\n"
					"ldr r10, =0x7f800000\t\n"
					"and r4, r1, r10\t\n"
					"and r5, r2, r10\t\n"
					"cmp r4, r5\t\n"
					"ITTTT cc\t\n"
					"movcc r3, r1\t\n"
					"movcc r1, r2\t\n"
					"movcc r2, r3\t\n"
					"andcc r4, r1, r10\t\n"
					"IT cc\t\n"
					"andcc r5, r2, r10\t\n"
					"mov r4, r4, lsr #23\t\n"
					"mov r5, r5, lsr #23\t\n"
					"sub r3, r4, r5\t\n"
					"ldr r10, =0x007fffff\t\n"
					"and r5, r1, r10\t\n"
					"and r6, r2, r10\t\n"
					"ldr r10, =0x00800000\t\n"
					"orr r5, r5, r10\t\n"
					"orr r6, r6, r10\t\n"
					"mov r6, r6, lsr r3\t\n"
					"ldr r10, =0x80000000\t\n"
					"ands r0, r1, r10\t\n"
					"IT ne\t\n"
					"movne r0, r5\t\n"
					"mvn r0, r0\t\n"
					"add r0, r0, #1\t\n"
					"IT ne\t\n"
					"movne r5, r0\t\n"
					"ands r0, r2, r10\t\n"
					"IT ne\t\n"
					"movne r0, r6\t\n"
					"mvn r0, r0\t\n"
					"add r0, r0, #1\t\n"
					"IT ne\t\n"
					"movne r6, r0\t\n"
					"add r5, r5, r6\t\n"
					"ands r0, r5, r10\t\n"
					"IT ne\t\n"
					"movne r0, r5\t\n"
					"mvn r0, r0\t\n"
					"add r0, r0, #1\t\n"
					"ITTE ne\t\n"
					"movne r5, r0\t\n"
					"ldrne r0, =0x80000000\t\n"
					"moveq r0, #0\t\n"
					"mov r3, #0\t\n"
					"ldr r10, =0x80000000\t\n"
					"ilePrzesuniec:\t\n"
					"cmp r10, r5\t\n"
					"ITT hi\t\n"
					"addhi r3, r3, #1\t\n"
					"movhi r10, r10, lsr #1\t\n"
					"bhi ilePrzesuniec\t\n"
					"cmp r3, #8\t\n"
					"ITTT hi\t\n"
					"subhi r3, r3, #8\t\n"
					"movhi r5, r5, lsl r3\t\n"
					"subhi r4, r4, r3\t\n"
					"ITTTT cc\t\n"
					"movcc r10, #8\t\n"
					"subcc r3, r10, r3\t\n"
					"movcc r5, r5, lsr r3\t\n"
					"addcc r4, r4, r3\t\n"
					"mov r4, r4, lsl #23\t\n"
					"orr r0, r0, r4\t\n"
					"ldr r10, =0x007fffff\t\n"
					"and r5, r5, r10\t\n"
					"orr r0, r0, r5\t\n"
					"mov %0, r0\t\n"
					:"+r"(wynik): "r" (op1), "r" (op2)
					 : "r1", "r2", "r3", "r4", "r5", "r6", "r10");
	}
	opResult = wynik;
}
void floatSub(){
	unsigned int wynik = 0;
	unsigned int przeciwne = op1^op2;
	if(przeciwne == 0){
		wynik = 0;
	}else {
		asm(	"mov r1, %1\t\n"
						"mov r2, %2\t\n"
						"ldr r10, =0x80000000\t\n"
						"eor r2, r2, r10\t\n"
						"ldr r10, =0x7f800000\t\n"
						"and r4, r1, r10\t\n"
						"and r5, r2, r10\t\n"
						"cmp r4, r5\t\n"
						"ITTTT cc\t\n"
						"movcc r3, r1\t\n"
						"movcc r1, r2\t\n"
						"movcc r2, r3\t\n"
						"andcc r4, r1, r10\t\n"
						"IT cc\t\n"
						"andcc r5, r2, r10\t\n"
						"mov r4, r4, lsr #23\t\n"
						"mov r5, r5, lsr #23\t\n"
						"sub r3, r4, r5\t\n"
						"ldr r10, =0x007fffff\t\n"
						"and r5, r1, r10\t\n"
						"and r6, r2, r10\t\n"
						"ldr r10, =0x00800000\t\n"
						"orr r5, r5, r10\t\n"
						"orr r6, r6, r10\t\n"
						"mov r6, r6, lsr r3\t\n"
						"ldr r10, =0x80000000\t\n"
						"ands r0, r1, r10\t\n"
						"IT ne\t\n"
						"movne r0, r5\t\n"
						"mvn r0, r0\t\n"
						"add r0, r0, #1\t\n"
						"IT ne\t\n"
						"movne r5, r0\t\n"
						"ands r0, r2, r10\t\n"
						"IT ne\t\n"
						"movne r0, r6\t\n"
						"mvn r0, r0\t\n"
						"add r0, r0, #1\t\n"
						"IT ne\t\n"
						"movne r6, r0\t\n"
						"add r5, r5, r6\t\n"
						"ands r0, r5, r10\t\n"
						"IT ne\t\n"
						"movne r0, r5\t\n"
						"mvn r0, r0\t\n"
						"add r0, r0, #1\t\n"
						"ITTE ne\t\n"
						"movne r5, r0\t\n"
						"ldrne r0, =0x80000000\t\n"
						"moveq r0, #0\t\n"
						"mov r3, #0\t\n"
						"ldr r10, =0x80000000\t\n"
						"ilePrzesuniecS:\t\n"
						"cmp r10, r5\t\n"
						"ITT hi\t\n"
						"addhi r3, r3, #1\t\n"
						"movhi r10, r10, lsr #1\t\n"
						"bhi ilePrzesuniecS\t\n"
						"cmp r3, #8\t\n"
						"ITTT hi\t\n"
						"subhi r3, r3, #8\t\n"
						"movhi r5, r5, lsl r3\t\n"
						"subhi r4, r4, r3\t\n"
						"ITTTT cc\t\n"
						"movcc r10, #8\t\n"
						"subcc r3, r10, r3\t\n"
						"movcc r5, r5, lsr r3\t\n"
						"addcc r4, r4, r3\t\n"
						"mov r4, r4, lsl #23\t\n"
						"orr r0, r0, r4\t\n"
						"ldr r10, =0x007fffff\t\n"
						"and r5, r5, r10\t\n"
						"orr r0, r0, r5\t\n"
						"mov %0, r0\t\n"
						:"+r"(wynik): "r" (op1), "r" (op2)
						 : "r1", "r2", "r3", "r4", "r5", "r6", "r10");
	}
	opResult = wynik;
}
void floatMul(){
	unsigned int s1 = 0, s2 = 0, e1 = 0, e2 = 0, m1 = 0, m2 = 0, wynik = 0;
	asm(	"mov r0, %7\t\n"
			"ldr r1, =#0x80000000\t\n"
			"and r1, r0, r1\t\n"
			"lsr r1, #31\t\n"
			"push {r1}\t\n"
			"mov %0, r1\t\n"
			"ldr r1, =0x7f800000\t\n"
			"and r1, r0, r1\t\n"
			"lsr r1, #23\t\n"
			"mov %2, r1\t\n"
			"ldr r1, =#0x7fffff\t\n"
			"and r1, r0, r1\t\n"
			"mov %4, r1\t\n"
			"mov r0, %8\t\n"
			"ldr r1, =#0x80000000\t\n"
			"and r1, r0, r1\t\n"
			"lsr r1, #31\t\n"
			"push {r1}\t\n"
			"mov %1, r1\t\n"
			"ldr r1, =#0x7f800000\t\n"
			"and r1, r0, r1\t\n"
			"lsr r1, #23\t\n"
			"mov %3, r1\t\n"
			"ldr r1, =#0x7fffff\t\n"
			"and r1, r0, r1\t\n"
			"mov %5, r1\t\n"
			"pop {r0}\t\n"
			"pop {r1}\t\n"
			"eor r1, r0, r1\t\n"
			"push {r1}\t\n"
			"lsl r1, #31\t\n"
			"mov %6, r1\t\n"
			"mov r0, %7\t\n"
			"and r0, r0, #0x7FFFFFFF\t\n"
			"ldr r3, =#0x7f800000\t\n"
			"cmp r0, r3\t\n"
			"beq zwrocInf\t\n"
			"bgt zwrocNan\t\n"
			"cmp r0, #0\t\n"
			"beq zwrocZero\t\n"
			"mov r0, %8\t\n"
			"and r0, r0, #0x7FFFFFFF\t\n"
			"ldr r3, =#0x7f800000\t\n"
			"cmp r0, r3\t\n"
			"beq zwrocInf\t\n"
			"bgt zwrocNan\t\n"
			"cmp r0, #0\t\n"
			"beq zwrocZero\t\n"
			"eor r0, r0\t\n"
			"eor r1, r1\t\n"
			"mov r0, %4\t\n"
			"mov r1, %5\t\n"
			"ldr r2, =#0x800000\t\n"
			"orr r0, r0, r2\t\n"
			"orr r1, r1, r2\t\n"
			"mov r2, r0\t\n"
			"umull r0, r3, r2, r1\t\n"
			"ldr r2, =#0xFFFF0000\t\n"
			"and r0, r0, r2\t\n"
			"lsr r0, #16\t\n"
			"lsl r3, #16\t\n"
			"orr r3, r0, r3\t\n"
			"mov r2, r3\t\n"
			"and r2, r2, #0xC0000000\t\n"
			"lsr r2, #30\t\n"
			"cmp r2, #1\t\n"
			"bgt znorm\t\n"
			"ldr r2, =#0\t\n"
			"push {r2}\t\n"
			"b znormalizowana\t\n"
			"znorm:\t\n"
			"lsr r3, #1\t\n"
			"ldr r2, =#1\t\n"
			"push {r2}\t\n"
			"znormalizowana:\t\n"
			"eor r2, r2\t\n"
			"add r3, r3, #40\t\n"
			"mov r2, r3\t\n"
			"and r2, r2, #0xC000000\t\n"
			"lsr r2, #30\t\n"
			"cmp r2, #1\t\n"
			"bgt znorm2\t\n"
			"b znormalizowana2\t\n"
			"znorm2:\t\n"
			"lsr r3, #1\t\n"
			"pop {r0}\t\n"
			"add r0, r0, #1\t\n"
			"push {r0}\t\n"
			"znormalizowana2:\t\n"
			"eor r2, r2\t\n"
			"and r3, r3, #0xFFFFFF80\t\n"
			"lsr r3, #7\t\n"
			"sub r3, r3, #0x800000\t\n"
			"eor r0, r0\t\n"
			"eor r1, r1\t\n"
			"mov r0, %2\t\n"
			"mov r1, %3\t\n"
			"add r1, r1, r0\t\n"
			"pop {r0}\t\n"
			"add r1, r1, r0\t\n"
			"sub r1, r1, #127\t\n"
			"cmp r1, #0\t\n"
			"blt zwrocInf\t\n"
			"znormalizowana3:\t\n"
			"lsl r1, #23\t\n"
			"mov r2, %6\t\n"
			"orr r1, r1, r2\t\n"
			"mov %6, r1\t\n"
			"mov r2, %6\t\n"
			"orr r3, r3, r2\t\n"
			"mov %6, r3\t\n"
			"b koniec\t\n"
			"zwrocInf:\t\n"
			"pop {r2}\t\n"
			"cmp r2, #0\t\n"
			"beq ustawPlusInf\t\n"
			"bgt ustawMinusInf\t\n"
			"ustawPlusInf:\t\n"
			"ldr r3, =#0x7f800000\t\n"
			"b ustawInf\t\n"
			"ustawMinusInf:\t\n"
			"ldr r3, =#0xff800000\t\n"
			"ustawInf:\t\n"
			"mov %6, r3\t\n"
			"b koniec\t\n"
			"zwrocNan:\t\n"
			"pop {r2}\t\n"
			"cmp r2, #0\t\n"
			"beq ustawPlusNan\t\n"
			"bgt ustawMinusNan\t\n"
			"ustawPlusNan:\t\n"
			"ldr r3, =#0x7fbfffff\t\n"
			"b ustawInf\t\n"
			"ustawMinusNan:\t\n"
			"ldr r3, =#0xffbfffff\t\n"
			"ustawNan:\t\n"
			"mov %6, r3\t\n"
			"b koniec\t\n"
			"zwrocZero:\t\n"
			"pop {r2}\t\n"
			"cmp r2, #0\t\n"
			"beq ustawPlusZero\t\n"
			"bgt ustawMinusZero\t\n"
			"ustawPlusZero:\t\n"
			"ldr r3, =#0x0\t\n"
			"b ustawZero\t\n"
			"ustawMinusZero:\t\n"
			"ldr r3, =#0x80000000\t\n"
			"ustawZero:\t\n"
			"mov %6, r3\t\n"
			"koniec:\t\n"
			: "+r" (s1), "+r" (s2), "+r" (e1), "+r" (e2), "+r" (m1), "+r" (m2), "+r" (wynik): "r" (op1), "r" (op2):"r0", "r1", "r2", "r3");
	opResult = wynik;
}
void floatDiv(){
	if(op2 == 0 || (op1 == 0 && op2 == 0)){
		opResult = 0xFF800001;
	}else {
		floatInverse(1);
		op2 = opResult;
		opResult = 0;
		floatMul();
	}
}
void floatPow(){
	unsigned int s1 = 0, s2 = 0, e1 = 0, e2 = 0, m1 = 0, m2 = 0, wynik = 0;
	op2 = op1;
		asm(	"mov r0, %7\t\n"
				"ldr r1, =#0x80000000\t\n"
				"and r1, r0, r1\t\n"
				"lsr r1, #31\t\n"
				"push {r1}\t\n"
				"mov %0, r1\t\n"
				"ldr r1, =0x7f800000\t\n"
				"and r1, r0, r1\t\n"
				"lsr r1, #23\t\n"
				"mov %2, r1\t\n"
				"ldr r1, =#0x7fffff\t\n"
				"and r1, r0, r1\t\n"
				"mov %4, r1\t\n"
				"mov r0, %8\t\n"
				"ldr r1, =#0x80000000\t\n"
				"and r1, r0, r1\t\n"
				"lsr r1, #31\t\n"
				"push {r1}\t\n"
				"mov %1, r1\t\n"
				"ldr r1, =#0x7f800000\t\n"
				"and r1, r0, r1\t\n"
				"lsr r1, #23\t\n"
				"mov %3, r1\t\n"
				"ldr r1, =#0x7fffff\t\n"
				"and r1, r0, r1\t\n"
				"mov %5, r1\t\n"
				"pop {r0}\t\n"
				"pop {r1}\t\n"
				"eor r1, r0, r1\t\n"
				"push {r1}\t\n"
				"lsl r1, #31\t\n"
				"mov %6, r1\t\n"
				"mov r0, %7\t\n"
				"and r0, r0, #0x7FFFFFFF\t\n"
				"ldr r3, =#0x7f800000\t\n"
				"cmp r0, r3\t\n"
				"beq zwrocInfP\t\n"
				"bgt zwrocNanP\t\n"
				"cmp r0, #0\t\n"
				"beq zwrocZeroP\t\n"
				"mov r0, %8\t\n"
				"and r0, r0, #0x7FFFFFFF\t\n"
				"ldr r3, =#0x7f800000\t\n"
				"cmp r0, r3\t\n"
				"beq zwrocInfP\t\n"
				"bgt zwrocNanP\t\n"
				"cmp r0, #0\t\n"
				"beq zwrocZeroP\t\n"
				"eor r0, r0\t\n"
				"eor r1, r1\t\n"
				"mov r0, %4\t\n"
				"mov r1, %5\t\n"
				"ldr r2, =#0x800000\t\n"
				"orr r0, r0, r2\t\n"
				"orr r1, r1, r2\t\n"
				"mov r2, r0\t\n"
				"umull r0, r3, r2, r1\t\n"
				"ldr r2, =#0xFFFF0000\t\n"
				"and r0, r0, r2\t\n"
				"lsr r0, #16\t\n"
				"lsl r3, #16\t\n"
				"orr r3, r0, r3\t\n"
				"mov r2, r3\t\n"
				"and r2, r2, #0xC0000000\t\n"
				"lsr r2, #30\t\n"
				"cmp r2, #1\t\n"
				"bgt znormP\t\n"
				"ldr r2, =#0\t\n"
				"push {r2}\t\n"
				"b znormalizowanaP\t\n"
				"znormP:\t\n"
				"lsr r3, #1\t\n"
				"ldr r2, =#1\t\n"
				"push {r2}\t\n"
				"znormalizowanaP:\t\n"
				"eor r2, r2\t\n"
				"add r3, r3, #40\t\n"
				"mov r2, r3\t\n"
				"and r2, r2, #0xC000000\t\n"
				"lsr r2, #30\t\n"
				"cmp r2, #1\t\n"
				"bgt znorm2P\t\n"
				"b znormalizowana2P\t\n"
				"znorm2P:\t\n"
				"lsr r3, #1\t\n"
				"pop {r0}\t\n"
				"add r0, r0, #1\t\n"
				"push {r0}\t\n"
				"znormalizowana2P:\t\n"
				"eor r2, r2\t\n"
				"and r3, r3, #0xFFFFFF80\t\n"
				"lsr r3, #7\t\n"
				"sub r3, r3, #0x800000\t\n"
				"eor r0, r0\t\n"
				"eor r1, r1\t\n"
				"mov r0, %2\t\n"
				"mov r1, %3\t\n"
				"add r1, r1, r0\t\n"
				"pop {r0}\t\n"
				"add r1, r1, r0\t\n"
				"sub r1, r1, #127\t\n"
				"cmp r1, #0\t\n"
				"blt zwrocInfP\t\n"
				"znormalizowana3P:\t\n"
				"lsl r1, #23\t\n"
				"mov r2, %6\t\n"
				"orr r1, r1, r2\t\n"
				"mov %6, r1\t\n"
				"mov r2, %6\t\n"
				"orr r3, r3, r2\t\n"
				"mov %6, r3\t\n"
				"b koniecP\t\n"
				"zwrocInfP:\t\n"
				"pop {r2}\t\n"
				"cmp r2, #0\t\n"
				"beq ustawPlusInfP\t\n"
				"bgt ustawMinusInfP\t\n"
				"ustawPlusInfP:\t\n"
				"ldr r3, =#0x7f800000\t\n"
				"b ustawInfP\t\n"
				"ustawMinusInfP:\t\n"
				"ldr r3, =#0xff800000\t\n"
				"ustawInfP:\t\n"
				"mov %6, r3\t\n"
				"b koniecP\t\n"
				"zwrocNanP:\t\n"
				"pop {r2}\t\n"
				"cmp r2, #0\t\n"
				"beq ustawPlusNanP\t\n"
				"bgt ustawMinusNanP\t\n"
				"ustawPlusNanP:\t\n"
				"ldr r3, =#0x7fbfffff\t\n"
				"b ustawInfP\t\n"
				"ustawMinusNanP:\t\n"
				"ldr r3, =#0xffbfffff\t\n"
				"ustawNanP:\t\n"
				"mov %6, r3\t\n"
				"b koniecP\t\n"
				"zwrocZeroP:\t\n"
				"pop {r2}\t\n"
				"cmp r2, #0\t\n"
				"beq ustawPlusZeroP\t\n"
				"bgt ustawMinusZeroP\t\n"
				"ustawPlusZeroP:\t\n"
				"ldr r3, =#0x0\t\n"
				"b ustawZeroP\t\n"
				"ustawMinusZeroP:\t\n"
				"ldr r3, =#0x80000000\t\n"
				"ustawZeroP:\t\n"
				"mov %6, r3\t\n"
				"koniecP:\t\n"
				: "+r" (s1), "+r" (s2), "+r" (e1), "+r" (e2), "+r" (m1), "+r" (m2), "+r" (wynik): "r" (op1), "r" (op2):"r0", "r1", "r2", "r3");
		opResult = wynik;
}
void floatSqrt(){
	unsigned int wynik = 0;
	if(op1 >= 0x80000000){
		wynik = 0xFF800001;
	}else if (op1 == 0){
		wynik = 0;
	}else {
		asm(	"mov r0, %1\t\n"
					"ldr r1, =#0x80000000\t\n"
					"and r1, r0, r1\t\n"
					"cmp r1, #0x80000000\t\n"
					"beq ujemnaSQ\t\n"
					"ldr r2, =#0x7f800000\t\n"
					"and r2, r0, r2\t\n"
					"ldr r3, =#0x800000\t\n"
					"and r3, r2, r3\t\n"
					"cmp r3, #0x800000\t\n"
					"beq omijajSQ\t\n"
					"sub r2, r2, #0x800000\t\n"
					"omijajSQ:\t\n"
					"cmp r2, #0x40000000\t\n"
					"blt maleSQ\t\n"
					"sub r2, r2, #0x3f800000\t\n"
					"lsr r2, #1\t\n"
					"add r2, r2, #0x3f800000\t\n"
					"b dalej\t\n"
					"maleSQ:\t\n"
					"ldr r4, =#0x3f800000\t\n"
					"eor r2, r2, r4\t\n"
					"lsr r2, #1\t\n"
					"eor r2, r2, r4\t\n"
					"sub r2, r2, #0x20000000\t\n"
					"dalej:\t\n"
					"ldr r4, =#0x7fffff\t\n"
					"and r4, r0, r4\t\n"
					"add r4, r4, #0x800000\t\n"
					"cmp r3, #0x800000\t\n"
					"beq omijaj2SQ\t\n"
					"lsl r4, #1\t\n"
					"omijaj2SQ:\t\n"
					"lsl r4, #1\t\n"
					"ldr r5, =#0\t\n"
					"ldr r6, =#0\t\n"
					"ldr r8, =#1\t\n"
					"ldr r9, =#0x3000000\t\n"
					"pierwiastkowanie:\t\n"
					"push {r9}\t\n"
					"and r9, r4, r9\t\n"
					"lsl r9, #2\t\n"
					"przesun:\t\n"
					"lsr r9, #2\t\n"
					"cmp r9, #3\t\n"
					"bgt przesun\t\n"
					"lsl r5, #2\t\n"
					"add r5, r9, r5\t\n"
					"lsl r6, #1\t\n"
					"cmp r5, r8\t\n"
					"blt omijaj4\t\n"
					"add r6, r6, #1\t\n"
					"sub r5, r5, r8\t\n"
					"omijaj4:\t\n"
					"mov r8, r6\t\n"
					"lsl r8, #2\t\n"
					"add r8, r8, #1\t\n"
					"pop {r9}\t\n"
					"lsr r9, #2\t\n"
					"cmp r9, #0\t\n"
					"bgt pierwiastkowanie\t\n"
					"ldr r10, =#0 \t\n"
					"dokladniej: \t\n"
					"lsl r5, #2 \t\n"
					"lsl r6, #1 \t\n"
					"cmp r5, r8 \t\n"
					"blt omijaj5 \t\n"
					"add r6,r6, #1 \t\n"
					"sub r5,r5, r8 \t\n"
					"omijaj5: \t\n"
					"mov r8, r6 \t\n"
					"lsl r8, #2 \t\n"
					"add r8, r8, r8 \t\n"
					"add r10, r10, #1 \t\n"
					"cmp r10, #11 \t\n"
					"blt dokladniej \t\n"
					"mov r4, r6 \t\n"
					"cmp r4, #0x800000 \t\n"
					"blt niedomiar \t\n"
					"sub r4, r4, #0x800000\t\n"
					"add r4, r4, r2\t\n"
					"add r4, r4, r1\t\n"
					"mov %0, r4\t\n"
					"niedomiar:\t\n"
					"ujemnaSQ:\t\n"
					"koniecSQ:\t\n"
					: "+r" (wynik)
					: "r" (op1): "r0", "r1", "r2", "r3", "r4", "r5", "r6", "r8", "r9", "r10");
	}
	opResult = wynik;
	prepareResult();
}
void floatInverse(int usedInAnotherAlg){
	unsigned int wynik = 0;
	unsigned int temp = 0;
	int resultChanged = 0;
	if(usedInAnotherAlg == 0){
		temp = op1;
		if(op1 == 0 || op1 == 0x80000000){
			resultChanged = 1;
		}
	}else {
		temp = op2;
	}
	asm(	"mov r0, %1\t\n"
			"ldr r1, =#0x80000000\t\n"
			"and r1, r0, r1\t\n"
			"push {r1}\t\n"
			"ldr r1, =#0x7f800000\t\n"
			"and r1, r0, r1\t\n"
			"ldr r2, =#0x3f800000\t\n"
			"eor r1, r2, r1\t\n"
			"ldr r3, =#0x7f800000\t\n"
			"eor r1, r3, r1\t\n"
			"add r1, r1, #0x800000\t\n"
			"eor r1, r2, r1\t\n"
			"sub r1, r1, #0x800000\t\n"
			"push {r1}\t\n"
			"ldr r1, =#0x7fffff\t\n"
			"and r1, r0, r1\t\n"
			"add r1, r1, #0x800000\t\n"
			"ldr r2, =#0x1000000\t\n"
			"ldr r3, =#0\t\n"
			"ldr r4, =#0\t\n"
			"sub r2, r2, r1\t\n"
			"dzielenie:\t\n"
			"lsr r1, #1\t\n"
			"lsl r4, #1\t\n"
			"cmp r1, #0\t\n"
			"beq koniecI\t\n"
			"cmp r2, #0\t\n"
			"bgt dodawanie\t\n"
			"add r2, r2, r1\t\n"
			"b dzielenie\t\n"
			"dodawanie:\t\n"
			"add r4, r4, #1\t\n"
			"sub r2, r2, r1\t\n"
			"b dzielenie\t\n"
			"koniecI:\t\n"
			"sub r4, r4, #0x800000\t\n"
			"pop {r1}\t\n"
			"pop {r2}\t\n"
			"add r4, r4, r1\t\n"
			"add r4, r4, r2\t\n"
			"mov %0, r4\t\n"
			:"+r" (wynik)
			:"r" (temp): "r0", "r1", "r2", "r3", "r4");
	if(resultChanged == 1){
		opResult = 0xFF800001;
	}else {
		opResult = wynik;
	}
}

int main(void) {
		GPIO_InitTypeDef gpio;
		USART_InitTypeDef uart;

		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

		GPIO_StructInit(&gpio);
		gpio.GPIO_Pin = GPIO_Pin_2;
		gpio.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_Init(GPIOA, &gpio);

		gpio.GPIO_Pin = GPIO_Pin_3;
		gpio.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		GPIO_Init(GPIOA, &gpio);


		USART_StructInit(&uart);
		uart.USART_BaudRate = 115200;
		USART_Init(USART2, &uart);

		USART_Cmd(USART2, ENABLE);

		int tmp = 0;
	for(;;) {
		if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE)){
			command[tmp] = USART_ReceiveData(USART2);
			if(tmp == 0){
				decodeOpcode(command[0]);
			}
			tmp++;
		}
		if(tmp == commandLength){
			prepareOperands();
			sendArray(result, 32);
			tmp = 0;
		}
		if(commandLength == -2){
			sendString("ERR!");
			tmp = 0;
			commandLength = -1;
		}
	}
}
